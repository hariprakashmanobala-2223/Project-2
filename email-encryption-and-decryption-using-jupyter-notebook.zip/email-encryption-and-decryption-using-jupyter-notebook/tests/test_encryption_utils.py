import unittest
from cryptography.fernet import InvalidToken
from src.encryption_utils import decrypt_message, encrypt_message, generate_key


class TestEncryptionUtils(unittest.TestCase):
    def test_round_trip(self):
        key = generate_key()
        message = "Hello! This is a sample email message."
        token = encrypt_message(message, key)
        self.assertNotEqual(token, message)
        self.assertEqual(decrypt_message(token, key), message)

    def test_wrong_key_fails(self):
        token = encrypt_message("secret", generate_key())
        with self.assertRaises(InvalidToken):
            decrypt_message(token, generate_key())


if __name__ == "__main__":
    unittest.main()
