"""Fernet helpers for the educational notebook project."""
from cryptography.fernet import Fernet


def generate_key() -> bytes:
    """Generate a new URL-safe Fernet key."""
    return Fernet.generate_key()


def encrypt_message(message: str, key: bytes) -> str:
    """Encrypt a UTF-8 message and return its token as text."""
    if not isinstance(message, str):
        raise TypeError("message must be a string")
    return Fernet(key).encrypt(message.encode("utf-8")).decode("utf-8")


def decrypt_message(token: str, key: bytes) -> str:
    """Decrypt a Fernet token and return the original message."""
    if not isinstance(token, str):
        raise TypeError("token must be a string")
    return Fernet(key).decrypt(token.encode("utf-8")).decode("utf-8")
