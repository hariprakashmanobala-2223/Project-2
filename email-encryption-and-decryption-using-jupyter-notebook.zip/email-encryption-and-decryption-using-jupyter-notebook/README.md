# Email Encryption and Decryption Using Jupyter Notebook

A beginner-friendly educational project demonstrating local message encryption and decryption with Python in Jupyter Notebook using the `cryptography` package (Fernet authenticated symmetric encryption).

> **Important:** This project encrypts message text locally. It does not connect to an email account, send emails, or automatically encrypt attachments. Use sample text only; never publish secret keys or confidential messages.

## Features
- Generate a symmetric encryption key
- Encrypt a message into ciphertext
- Decrypt ciphertext with the matching key
- Demonstrate why the wrong key fails
- Run the examples interactively in Jupyter Notebook

## Project structure

```text
email-encryption-and-decryption-using-jupyter-notebook/
├── README.md
├── LICENSE
├── .gitignore
├── requirements.txt
├── notebooks/
│   └── email_encryption_decryption.ipynb
├── src/
│   ├── __init__.py
│   └── encryption_utils.py
└── tests/
    └── test_encryption_utils.py
```

## Requirements
- Python 3.10 or newer
- Jupyter Notebook
- `cryptography`

## Installation
1. Extract the ZIP file and open a terminal in the project folder.
2. (Recommended) Create a virtual environment.

Windows:
```bash
python -m venv .venv
.venv\\Scripts\\activate
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Start Jupyter:
```bash
jupyter notebook
```

Open `notebooks/email_encryption_decryption.ipynb` and run the cells from top to bottom.

## Run tests
```bash
python -m unittest discover -s tests
```

## How it works
1. Generate a Fernet key.
2. Encrypt UTF-8 message text with that key.
3. Display the encrypted token.
4. Decrypt the token using the same key.
5. Verify that a wrong key cannot decrypt the token.

Fernet is authenticated symmetric encryption: the same secret key is required to decrypt the message.

## Security notes
- Never commit secret keys, credentials, real email contents, or `.env` files to GitHub.
- Losing the key means encrypted data cannot be recovered.
- This project does not provide end-to-end email encryption or encrypt attachments.
- For real sensitive email, investigate established tools and standards such as OpenPGP or S/MIME.

## Upload to GitHub
1. Create a repository on [GitHub](https://github.com/), e.g. `email-encryption-and-decryption-using-jupyter-notebook`.
2. Extract this ZIP.
3. Upload the **contents** of the extracted folder (not just the ZIP file), including `README.md` and `LICENSE`.
4. Commit the changes.

Alternatively, from the project root:
```bash
git init
git add .
git commit -m "Initial email encryption notebook project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/email-encryption-and-decryption-using-jupyter-notebook.git
git push -u origin main
```
Replace `YOUR-USERNAME` with your GitHub username.

## License
Released under the MIT License. See [LICENSE](LICENSE).
